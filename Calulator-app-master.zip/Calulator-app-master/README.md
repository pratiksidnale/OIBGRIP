# Calulator-app
Oasis Infobyte Android development

Task-3

The aim of this task is to create an Calculator that can perform varies arithmatic operation like addition, subtraction, ect... 
