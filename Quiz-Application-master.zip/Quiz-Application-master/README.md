# Quiz-Application
Oasis Infobyte Android development 

Task4

The aim of this task is to create an quiz app that has mulitiple quizes on multiple pages.

App is connected to the pages and keeps record of score of the user.

at the last page the total score is displayed.


