# Stop-watch-app
About Oasis Infobyte Android development 

Task5

This task aims for a simple stop watch app.
